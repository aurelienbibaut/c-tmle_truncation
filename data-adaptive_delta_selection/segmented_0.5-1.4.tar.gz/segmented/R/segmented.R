`segmented` <-
function(obj, seg.Z, psi, control=seg.control(), model=TRUE, ...){
            UseMethod("segmented")
            }
